## [0.0.1] - Dec 22nd, 2021

* Released with null-safety-support

## [0.0.2] - Dec 28, 2021

* Dynamically change background color of places field

## [0.0.4] - Dec 28, 2021

* Dynamically change text color of places field