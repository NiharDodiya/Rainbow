## [0.7.0]
- Upgraded flutter version

## [0.6.0]
- Added possibility to pause and resume indicator animation
- Added onPageChanged

## [0.5.1] 
- Fixed the problem 'initialStoryIndex' does not work.

## [0.5.0] 
- Supported null safety

## [0.4.0] 
- Added `gestureItemBuilder`

## [0.3.0+1] 
- Added a close button to example

## [0.3.0] 
- Fixed a bug `onPageLimitReached` is called multiple time.

## [0.2.0] 
- Fixed a bug when initialIndex is not 0

## [0.1.0+2] 
- Fixed README.md

## [0.1.0+1] 
- Fixed README.md

## [0.1.0] 
- Initial release

## [0.0.1] 
- Release to submit the name of the package
