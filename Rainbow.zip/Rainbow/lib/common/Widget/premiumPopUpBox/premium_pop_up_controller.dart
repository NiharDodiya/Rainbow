import 'package:get/get.dart';

class SubscribePopUpController extends GetxController {
  /*SubscriptionAddApi() async{
    await UserSubscriptionAddApi.userSubscriptionAddApi();
  }*/

}
