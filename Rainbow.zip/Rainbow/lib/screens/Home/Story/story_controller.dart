import 'package:get/get.dart';

class EditStoryController extends GetxController {}
