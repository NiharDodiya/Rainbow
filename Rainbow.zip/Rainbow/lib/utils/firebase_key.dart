class FirebaseKeys {
  ///_________________________________________ cloud_firestore _________________________________________
  static const users = "Users";
  static const chatRoom = "ChatRoom";
  static const adMob = "AdMob";

  static const banner = "banner";
  static const interstitial = "interstitial";
  static const reward = "reward";
  static const applicationId = "application_id";
  static const registerId = "registerId_id";

  ///_________________________________________ firebase_storage _________________________________________
  static const userProfile = "userProfile";
}
