class FontRes {
  static const gilroyBold = "Gilroy-Bold";
  static const gilroySemiBold = "Gilroy-SemiBold";
  static const gilroyMedium = "Gilroy-Medium";
  static const gilroyRegular = "Gilroy-Regular";
  static const beVietnamProBold = "BeVietnamPro-Bold";
  static const beVietnamProSemiBold = "BeVietnamPro-SemiBold";
  static const beVietnamProMedium = "BeVietnamPro-Medium";
  static const beVietnamProRegular = "BeVietnamPro-Regular";
  static const montserratRegular = "Montserrat-Regular";
  static const sFProText = "SF-Pro-Text";
  static const inter = "Inter.ttf";

  static const poppinsSemiBold = "Poppins-SemiBold";
  static const poppinsMedium = "Poppins-Medium";
  static const poppinsRegular = "Poppins-Regular";
}
